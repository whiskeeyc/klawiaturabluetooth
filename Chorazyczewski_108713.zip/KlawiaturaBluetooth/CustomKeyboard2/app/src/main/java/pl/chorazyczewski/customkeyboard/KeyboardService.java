package pl.chorazyczewski.customkeyboard;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.drawable.Drawable;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.nfc.NfcAdapter;
import android.nfc.NfcManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

import pl.chorazyczewski.customkeyboard.R;

public class KeyboardService extends InputMethodService implements KeyboardView.OnKeyboardActionListener{


    @Override
    public View onCreateInputView() {

        KeyboardView keyboardView = (KeyboardView) getLayoutInflater().inflate(R.layout.keyboard_view, null);
        Keyboard keyboard = new Keyboard(this, R.xml.number_pad);
        keyboardView.setKeyboard(keyboard);
        keyboardView.setOnKeyboardActionListener(this);
        return keyboardView;
    }
    public View onCreateInputView2() {

        KeyboardView keyboardView = (KeyboardView) getLayoutInflater().inflate(R.layout.keyboard_view, null);
        Keyboard keyboard = new Keyboard(this, R.xml.number_pad2);
        keyboardView.setKeyboard(keyboard);
        keyboardView.setOnKeyboardActionListener(this);
        return keyboardView;
    }

    public void toastMsg(String msg) {

        Toast toast = Toast.makeText(this, msg, Toast.LENGTH_LONG);
        toast.show();

    }

    String isnfc = "";
    String connec = "No Internet Connection";


    @Override
    public void onKey(int primaryCode, int[] keyCodes) {

        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        Context context = getApplicationContext();

        Uri sound = RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_NOTIFICATION);
        MediaPlayer mp = MediaPlayer.create(context, sound);
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        int volume_level= am.getStreamVolume(AudioManager.STREAM_SYSTEM);
        if(volume_level>0) mp.start();

        switch (primaryCode) {
            case 49:
                CharSequence selectedText = ic.getSelectedText(0);
                ic.commitText("THIS IS A CUSTOM KEYBOARD !", 1);
                break;
            case 50:
                MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.sample);
                mediaPlayer.start();
                break;

            case 51:
                Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                break;
            case 52:
                String filePath = getApplicationContext().getFilesDir().getPath();

                try{
                    File root = new File(filePath);
                    File gpxfile = new File(root, "text.txt");
                    FileWriter writer = new FileWriter(gpxfile);
                    writer.append("Zapisany text");
                    writer.flush();
                    writer.close();

                    StringBuilder text = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new FileReader(gpxfile));
                    String nl;

                    while((nl = bufferedReader.readLine()) != null){
                        text.append(nl);
                        text.append('\n');
                    }
                    bufferedReader.close();
                    System.out.println("Ostatnio zapisany tekst: "+text);
                }
                catch (IOException e){
                    Log.e("Exception", "Write to file failed" + e.toString());

                }finally{
                    break;
                }

            case 53:
                toastMsg("Welcome to my app");
                break;
            case 54:
                setInputView(onCreateInputView2());
                break;
            case 55:
                setInputView(onCreateInputView());
                break;
            case 56:
                NfcManager manager = (NfcManager) getApplicationContext().getSystemService(Context.NFC_SERVICE);
                NfcAdapter adapter = manager.getDefaultAdapter();

                if (adapter != null && adapter.isEnabled()){
                    isnfc = "NFC is ON";
                }   else {
                    isnfc = "NFC is OFF";
                }
                toastMsg(isnfc);
                break;
            case 57:
                Intent intent2 = new Intent(Settings.ACTION_NFC_SETTINGS);
                intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent2);
                break;
            case 58:
                Intent intent3 = new Intent(Intent.ACTION_VIEW);
                intent3.setType("image/*");
                intent3.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent3);
                break;
            case 59:
                ConnectivityManager connectivity = (ConnectivityManager) getBaseContext().getSystemService(Context.CONNECTIVITY_SERVICE);
                if (connectivity != null)
                {
                    NetworkInfo[] info = connectivity.getAllNetworkInfo();
                    if (info != null)
                        for (int i = 0; i < info.length; i++)
                            if (info[i].getState() == NetworkInfo.State.CONNECTED)
                            {
                                connec = "Has Internet Connection";
                            }
                }
                toastMsg(connec);
                break;
            case 60:
                System.out.println("ConnectedThread is null?  "+GlobalVar.getCtClient().isAlive());
                GlobalVar.getCtClient().write("616000010000123".getBytes());
                break;
            case 61:
                System.out.println("ConnectedThread is null?  "+GlobalVar.getCtClient().isAlive());
                GlobalVar.getCtClient().write("616000010000124".getBytes());
                break;
            case 62:
                InputMethodManager imeManager = (InputMethodManager) getApplicationContext().getSystemService(INPUT_METHOD_SERVICE);
                imeManager.showInputMethodPicker();

                break;
            case -101:
                runServer();
                break;

            default:

        }
    }



    @Override
    public void onPress(int primaryCode) { }

    @Override
    public void onRelease(int primaryCode) { }

    @Override
    public void onText(CharSequence text) { }

    @Override
    public void swipeLeft() { }

    @Override
    public void swipeRight() { }

    @Override
    public void swipeDown() { }

    @Override
    public void swipeUp() { }



    private static final UUID MY_UUID =
            UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");

    private void runServer(){
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (!bluetoothAdapter.isEnabled()) {
        }
        Log.e(TAG,"RUNNING BLUETOOTH SERVICE");
        AcceptThread at = new AcceptThread();
        at.start();
    }

    private class AcceptThread extends Thread {
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        private final BluetoothServerSocket mmServerSocket;

        public AcceptThread() {

            BluetoothServerSocket tmp = null;
            try {
                tmp = bluetoothAdapter.listenUsingRfcommWithServiceRecord("MY_APP", MY_UUID);
            } catch (IOException e) {
                Log.e(TAG, "Socket's listen() method failed", e);
            }
            mmServerSocket = tmp;
        }

        public void run() {
            BluetoothSocket socket = null;
            // Keep listening until exception occurs or a socket is returned.
            while (true) {
                try {
                    socket = mmServerSocket.accept();
                } catch (IOException e) {
                    Log.e(TAG, "Socket's accept() method failed", e);
                    break;
                }

                if (socket != null) {
                    // A connection was accepted. Perform work associated with
                    // the connection in a separate thread.
                    ConnectedThread ct = new ConnectedThread(socket);
                    Log.e(TAG,"TRY RUN CONNECTED THREAD");
                    ct.start();
                    try {
                        mmServerSocket.close();
                    }
                    catch (Exception e){
                        Log.e(TAG, "BLAD 1: ",e);
                    }
                    break;
                }
            }
        }

        // Closes the connect socket and causes the thread to finish.
        public void cancel() {
            try {
                mmServerSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "Could not close the connect socket", e);
            }
        }
    }


////////////////            SERVICe

    private static final String TAG = "MY_APP_DEBUG_TAG";
    //private Handler handler; // handler that gets info from Bluetooth service

    private Handler handler = new Handler(new Handler.Callback() {

        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what) {
                case MessageConstants.MESSAGE_READ:
                    byte[] readBuf = (byte[]) msg.obj;
                    String readMessage = new String(readBuf, 0, msg.arg1);
                    Log.e(TAG,"Odczytano wiadomosc: "+readMessage);
                    break;
            }
            return false;
        }
    });


    // Defines several constants used when transmitting messages between the
    // service and the UI.
    private interface MessageConstants {
        public static final int MESSAGE_READ = 0;
        public static final int MESSAGE_WRITE = 1;
        public static final int MESSAGE_TOAST = 2;

        // ... (Add other message types here as needed.)
    }

    private class ConnectedThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;
        private byte[] mmBuffer; // mmBuffer store for the stream

        public ConnectedThread(BluetoothSocket socket) {
            Log.e(TAG,"NAWIAZANO POLACZENIE");
            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            try {
                tmpIn = socket.getInputStream();
            } catch (IOException e) {
                Log.e(TAG, "Error occurred when creating input stream", e);
            }
            try {
                tmpOut = socket.getOutputStream();
            } catch (IOException e) {
                Log.e(TAG, "Error occurred when creating output stream", e);
            }
            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {
            mmBuffer = new byte[1024];
            int numBytes; // bytes returned from read()
            Log.e(TAG,"CONNECTED THREAD RUNNING");
            // Keep listening to the InputStream until an exception occurs.
            while (true) {
                try {
                    // Read from the InputStream.
                    numBytes = mmInStream.read(mmBuffer);
                    String readMessage = new String(mmBuffer, 0, numBytes);
                    Log.e(TAG,String.valueOf(numBytes));
                    Log.e(TAG,"NOWE ODCZYTANO: "+readMessage);
                    InputConnection ic = getCurrentInputConnection();
                    if (ic != null) {
                        ic.commitText(readMessage, 1);
                    }else {
                        Log.e(TAG, "NIE ZNALAZLEM INPUT");
                    }

                    // Send the obtained bytes to the UI activity.
                    Message readMsg = handler.obtainMessage(
                            MessageConstants.MESSAGE_READ, numBytes, -1,
                            mmBuffer);
                    readMsg.sendToTarget();
                } catch (IOException e) {
                    Log.d(TAG, "Input stream was disconnected", e);
                    break;
                }
            }
        }


    }





}